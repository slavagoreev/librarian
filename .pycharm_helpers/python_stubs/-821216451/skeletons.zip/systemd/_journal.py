# encoding: utf-8
# module systemd._journal
# from /usr/lib/python3/dist-packages/systemd/_journal.cpython-35m-x86_64-linux-gnu.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

__version__ = '231'

# functions

def sendv(*args, **kwargs): # real signature unknown; NOTE: unreliably restored from __doc__ 
    """
    sendv('FIELD=value', 'FIELD=value', ...) -> None
    
    Send an entry to the journal.
    """
    pass

def stream_fd(identifier, priority, level_prefix): # real signature unknown; restored from __doc__
    """
    stream_fd(identifier, priority, level_prefix) -> fd
    
    Open a stream to journal by calling sd_journal_stream_fd(3).
    """
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

