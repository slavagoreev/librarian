# encoding: utf-8
# module _testimportmultiple
# from /usr/lib/python3.5/lib-dynload/_testimportmultiple.cpython-35m-x86_64-linux-gnu.so
# by generator 1.145
""" _testimportmultiple doc """
# no imports

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

