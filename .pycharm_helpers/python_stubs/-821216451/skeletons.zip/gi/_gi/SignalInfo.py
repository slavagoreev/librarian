# encoding: utf-8
# module gi._gi
# from /usr/lib/python3/dist-packages/gi/_gi.cpython-35m-x86_64-linux-gnu.so
# by generator 1.145
# no doc

# imports
import _gobject as _gobject # <module '_gobject'>
import _glib as _glib # <module '_glib'>
import gi as __gi
import gobject as __gobject


class SignalInfo(__gi.CallableInfo):
    # no doc
    def get_class_closure(self, *args, **kwargs): # real signature unknown
        pass

    def get_flags(self, *args, **kwargs): # real signature unknown
        pass

    def true_stops_emit(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


