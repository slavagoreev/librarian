# encoding: utf-8
# module fpectl
# from /usr/lib/python3.5/lib-dynload/fpectl.cpython-35m-x86_64-linux-gnu.so
# by generator 1.145
# no doc
# no imports

# functions

def turnoff_sigfpe(*args, **kwargs): # real signature unknown
    pass

def turnon_sigfpe(*args, **kwargs): # real signature unknown
    pass

# classes

class error(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

