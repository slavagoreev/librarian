# encoding: utf-8
# module cython_runtime
# from /usr/local/lib/python3.5/dist-packages/zmq/devices/monitoredqueue.cpython-35m-x86_64-linux-gnu.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

cline_in_traceback = False

__loader__ = None

__spec__ = None

# no functions
# no classes
